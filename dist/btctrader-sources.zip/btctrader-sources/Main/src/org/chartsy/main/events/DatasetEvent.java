package org.chartsy.main.events;

import java.util.EventObject;

/**
 *
 * @author viorel.gheba
 */
public class DatasetEvent 
        extends EventObject
{

    public DatasetEvent(Object source)
    { super(source); }

}
