package org.chartsy.main.utils;

import java.awt.geom.Rectangle2D;

/**
 *
 * @author viorel.gheba
 */
public class Bounds extends Rectangle2D.Double {

    public Bounds(double x, double y, double width, double height) { super(x, y, width, height); }

}
