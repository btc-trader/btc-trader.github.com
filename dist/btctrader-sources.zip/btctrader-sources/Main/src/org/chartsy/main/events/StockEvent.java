package org.chartsy.main.events;

import java.util.EventObject;

/**
 *
 * @author viorel.gheba
 */
public class StockEvent extends EventObject {

    public StockEvent(Object source)
    { super(source); }

}
