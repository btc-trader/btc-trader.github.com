package org.chartsy.main.events;

import java.util.EventObject;

/**
 *
 * @author viorel.gheba
 */
public class LogEvent extends EventObject {

    public LogEvent(Object source)
    { super(source); }

}
