package org.chartsy.main.events;

/**
 *
 * @author Viorel
 */
public abstract class DataProviderAdapter implements DataProviderListener
{

	public void triggerDataProviderListener(DataProviderEvent evt) {}

}
