@org.netbeans.spi.options.OptionsPanelController.ContainerRegistration(id = "DataFeeds", categoryName = "#OptionsCategory_Name_DataFeeds", iconBase = "org/chartsy/main/options/datafeed.png", keywords = "#OptionsCategory_Keywords_DataFeeds", keywordsCategory = "DataFeeds")
package org.chartsy.main.options;
