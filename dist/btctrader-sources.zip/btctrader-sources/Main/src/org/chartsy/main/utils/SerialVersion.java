package org.chartsy.main.utils;

/**
 *
 * @author Viorel
 */
public class SerialVersion
{
    public static final long APPVERSION = 120L;
}
